package dao;

import org.springframework.stereotype.Repository;

import bao.Employees;
import scs.welcomespring.Employee;

@Repository
public class EmployeeDAO {
	 private static Employees list= new Employees();
	 static
	 {

	     // Creating a few employees
	     // and adding them to the list
	     list.getEmployeeList().add(
	         new Employee(
	             1,
	             "Prem",
	             "Cleark"
	            ));

	     list.getEmployeeList().add(
	         new Employee(
	             2, "Vikash",
	             "Manager"));

	     list.getEmployeeList().add(
	         new Employee(
	             3, "Ritesh",
	             "Developer"
	            ));

	        
	 }
	 public Employees getAllEmployees()
	 {

	     return list;
	 }
	 public void addEmployee(Employee employee)
      {
           list.getEmployeeList().add(employee);
      }
	 
	
	 
}
